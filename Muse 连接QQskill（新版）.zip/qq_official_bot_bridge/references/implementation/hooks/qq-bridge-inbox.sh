#!/usr/bin/env bash
# qq-bridge wake hook: poll the bridge inbox for new QQ message files.
# State (filenames already woken for) lives in ~/hooks/state so each
# message wakes the agent at most once; the daemon archives files to
# done/ after replying, and QQ message ids are unique, so the seen
# list never needs pruning for correctness.
set -euo pipefail
source "$HATCH_HOOK_RUNTIME"

INBOX="$HOME/workspace/qq-bridge/inbox"
STATE_DIR="$HOME/hooks/state"
STATE_FILE="$STATE_DIR/qq-bridge-inbox.seen"
mkdir -p "$STATE_DIR"
touch "$STATE_FILE"

new_files=()
shopt -s nullglob
for f in "$INBOX"/*.json; do
  base="$(basename "$f")"
  if ! grep -qxF -- "$base" "$STATE_FILE"; then
    new_files+=("$base")
  fi
done

if [ "${#new_files[@]}" -eq 0 ]; then
  silent "qq-bridge inbox has no new messages" '{}'
else
  if [ "${HATCH_HOOK_DRY_RUN:-0}" != "1" ]; then
    printf '%s\n' "${new_files[@]}" >> "$STATE_FILE"
  fi
  payload="$(printf '%s\n' "${new_files[@]}" | jq -R . | jq -s '{files: .}')"
  log "new QQ inbox message file(s) detected" "$payload"
  wake "new QQ message(s) waiting in the qq-bridge inbox" "$payload"
fi
