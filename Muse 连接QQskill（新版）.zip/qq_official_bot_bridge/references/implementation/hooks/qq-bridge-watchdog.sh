#!/usr/bin/env bash
# qq-bridge watchdog: keep the bridge daemon alive.
# - No credentials file -> nothing to guard, stay silent.
# - Daemon running -> silent.
# - Daemon down -> restart it (same nohup command used manually), log to
#   the bridge's logs/watchdog.log, stay silent unless the restart fails
#   or restarts exceed 3 within an hour (restart loop) -> wake the agent.
set -euo pipefail
source "$HATCH_HOOK_RUNTIME"

BRIDGE="$HOME/workspace/qq-bridge"
CREDS="$BRIDGE/credentials.env"
STATE_DIR="$HOME/hooks/state"
STATE_FILE="$STATE_DIR/qq-bridge-watchdog.restarts"
WATCHDOG_LOG="$BRIDGE/logs/watchdog.log"
PATTERN="venv/bin/python daemon.py"
mkdir -p "$STATE_DIR" "$BRIDGE/logs"

if [ ! -f "$CREDS" ]; then
  silent "qq-bridge credentials.env absent; watchdog idle" '{}'
fi

if pgrep -f "$PATTERN" >/dev/null 2>&1; then
  silent "qq-bridge daemon is running" '{}'
fi

# Daemon is down.
now="$(date +%s)"
count_last_hour=0
if [ -f "$STATE_FILE" ]; then
  count_last_hour="$(awk -v cutoff="$((now - 3600))" '$1 >= cutoff' "$STATE_FILE" | wc -l)"
fi

if [ "${HATCH_HOOK_DRY_RUN:-0}" = "1" ]; then
  silent "dry run: qq-bridge daemon not running (would restart; $count_last_hour restart(s) in the last hour)" '{}'
fi

# Record this restart attempt (prune entries older than one hour first).
if [ -f "$STATE_FILE" ]; then
  awk -v cutoff="$((now - 3600))" '$1 >= cutoff' "$STATE_FILE" > "$STATE_FILE.tmp" || true
  mv "$STATE_FILE.tmp" "$STATE_FILE"
fi
echo "$now" >> "$STATE_FILE"
count_last_hour=$((count_last_hour + 1))

echo "[$(date '+%Y-%m-%d %H:%M:%S %z')] daemon not running; restarting (attempt $count_last_hour in the last hour)" >> "$WATCHDOG_LOG"
setsid bash -c 'cd "$1" && exec .venv/bin/python daemon.py >> logs/daemon-stdout.log 2>&1' _ "$BRIDGE" < /dev/null & disown || true
sleep 5

if pgrep -f "$PATTERN" >/dev/null 2>&1; then
  echo "[$(date '+%Y-%m-%d %H:%M:%S %z')] restart succeeded" >> "$WATCHDOG_LOG"
  log "qq-bridge daemon restarted by watchdog" "{\"restarts_last_hour\": $count_last_hour}"
  if [ "$count_last_hour" -gt 3 ]; then
    wake "qq-bridge daemon is in a restart loop ($count_last_hour restarts in the last hour)" "{\"restarts_last_hour\": $count_last_hour}"
  fi
  silent "qq-bridge daemon restarted successfully" "{\"restarts_last_hour\": $count_last_hour}"
fi

echo "[$(date '+%Y-%m-%d %H:%M:%S %z')] restart FAILED: daemon still not running" >> "$WATCHDOG_LOG"
log "qq-bridge daemon restart failed" "{\"restarts_last_hour\": $count_last_hour}"
wake "qq-bridge daemon is down and the watchdog restart attempt failed" "{\"restarts_last_hour\": $count_last_hour}"
