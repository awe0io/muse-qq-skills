# qq-bridge — QQ 官方机器人 ⇄ Muse (Lora) 文件桥

让 QQ 里的消息由 Lora 本人（Muse agent）来回复。中间不经过任何外部
LLM：守护进程只负责收发，回复内容由一个 Muse agent 回合写出。

## 流程

```
QQ 用户 ──消息──▶ QQ 开放平台 ──WebSocket 网关──▶ daemon.py
                                                     │ 写入（含附件/语音转写）
                                                     ▼
                                              inbox/<msg_id>.json
                                                     │ hook 轮询发现新文件
                                                     ▼
                                        Muse agent 回合（Lora 人格/记忆）
                                                     │ 写入 {"reply": ...}
                                                     ▼
                                              outbox/<msg_id>.json
                                                     │ daemon 每 ~3 秒轮询
                                                     ▼
                  官方 OpenAPI v2 被动回复（引用原 msg_id；文本/Markdown/富媒体）
                                                     │
                                                     ▼
                                        两个文件归档到 done/ + 结果标记
```

另外两条旁路：

- **主动消息**：往 `proactive/` 放 `{"scene", "target", "content", ...}`
  文件，daemon 以主动消息发出（不引用任何 msg_id），归档时带
  `.SENT` / `.FAILED` 标记，平台返回的错误（HTTP 状态/业务码+消息）
  会原样记入日志。
- **事件**：按钮交互（INTERACTION_CREATE）会被 daemon 通过官方
  `acknowledge_interaction` 接口确认，交互与生命周期事件
  （FRIEND_ADD、GROUP_ADD_ROBOT 等）逐条追加到 `events/events.jsonl`，
  不进 inbox、不回复。

组件：

- `daemon.py` — 基于腾讯官方 `tencent-connect/qqbot-agent-sdk`
  （WebSocket Gateway + OpenAPI v2，纯 Python）。负责连接网关、收消息、
  发被动/主动消息。不使用任何非官方协议端。
- hook `qq-bridge-inbox`（脚本 `~/hooks/scripts/qq-bridge-inbox.sh`）—
  每 10 秒轮询 `inbox/`，发现新消息文件就唤醒一个 agent 回合去写回复。
  **已启用。**
- hook `qq-bridge-watchdog`（脚本 `~/hooks/scripts/qq-bridge-watchdog.sh`）—
  每 60 秒检查守护进程是否在跑：凭据文件不存在时静默跳过；进程不在时
  用 nohup 拉起并记 `logs/watchdog.log`；拉起失败、或 1 小时内重启超过
  3 次时才唤醒 agent 向主聊天报告。**已启用。**
- `qq-bridge.service` — systemd 用户服务（`Restart=on-failure`），
  已放在 `~/.config/systemd/user/`，**尚未启用**（当前 daemon 由 nohup
  直接拉起，看门狗负责保活）。

## 覆盖矩阵（对官方 SDK qqbot-agent-sdk 1.2.2 审计后补齐）

接收：

| 类型 | 状态 | 说明 |
|---|---|---|
| 单聊 C2C 文字 | ✅ 已实测 | 私聊直接回复 |
| 群 @ 文字 | ✅ 已实测 | 群里 @机器人 触发 |
| 图片/视频/文件附件 | ✅ 已实现（离线验证） | 附件元数据（文件名/类型/URL/大小）随记录入箱；纯附件消息以 `attachment_only: true` 入箱，不再丢弃 |
| 语音消息 | ✅ 已实现（离线验证） | 走 SDK 的 STTPipeline：有 STT 引擎配置时调引擎转写，否则用平台事件自带的 `asr_refer_text`；两者都无时 `asr_text: null` 并附 `asr_note` 说明原因，不伪造转写 |
| 引用消息 | ✅ 已实现（离线验证） | `msg_elements`（被引用内容/附件）与 `message_reference` 随记录入箱 |
| 频道消息 / 频道私信 | ✅ 已实现（离线验证） | scene 为 `guild` / `dm`，回复分别走频道发送路径与 `/dms` 接口 |
| 群全量消息 GROUP_MESSAGE_CREATE | ⚠️ 已实现（离线验证），实时到达待实测 | SDK 不支持（见下「SDK 限制」），daemon 自行注册解析器 + 子类分发；平台侧还需给机器人开群全量消息权限 |
| 按钮交互 INTERACTION_CREATE | ✅ 已实现（离线验证） | 自动 ACK，并记入 events.jsonl |
| 生命周期事件（FRIEND_ADD 等） | ✅ 已实现（离线验证） | 记入 events.jsonl；平台是否推送取决于应用订阅的事件范围 |

发送：

| 类型 | 状态 | 说明 |
|---|---|---|
| 纯文本被动回复 | ✅ 已实测 | `{"reply": "..."}` |
| Markdown | ✅ 已实现（离线验证） | outbox 加 `"markdown": true`（C2C/群/频道；频道私信仍为纯文本） |
| 富媒体（图片/视频/语音/文件） | ✅ 已实现（离线验证） | outbox 加 `"media": [...]`，经 SDK 上传接口（大文件自动分片）以 msg_type 7 发出；有文字时文字随第一条媒体消息一起发。仅 C2C/群：SDK 的上传接口只支持这两类，频道/私信的 media 会被跳过并记日志 |
| 正在输入状态 | ✅ 已实现 | C2C 消息入箱时自动发 `send_typing`（尽力而为，失败只记日志） |
| 主动消息 | ✅ 已实现（离线验证） | 见 `proactive/` 格式；受平台主动消息配额约束，配额错误原样记日志 |

## 目录

| 路径 | 用途 |
|---|---|
| `inbox/` | 待回复的消息，记录结构见下 |
| `outbox/` | agent 写出的回复，文件名与 inbox 对应，格式见下 |
| `proactive/` | 待发的主动消息文件，格式见下 |
| `events/events.jsonl` | 交互与生命周期事件日志（每行一个 JSON） |
| `done/` | 已处理归档：消息文件、`.reply.json`、`.proactive.json`、结果标记（`.SENT` / `.EXPIRED` / `.INVALID` / `.ORPHAN` / `.FAILED`） |
| `logs/daemon.log` | 守护进程日志（不含密钥） |
| `logs/watchdog.log` | 看门狗重启记录 |
| `state/` | WebSocket 会话恢复状态、附件缓存 |
| `tests/` | 离线测试套件（stub API）：`tests/test_bridge_offline.py` |
| `.venv/` | Python 虚拟环境（qqbot-agent-sdk 1.2.2） |

### inbox 记录结构

```json
{
  "msg_id": "...", "scene": "c2c|group|guild|dm", "event_type": "...",
  "user_openid": "发送者", "group_openid": null, "channel_id": null,
  "chat_id": "回复路由目标",
  "content": "正文（可为空）", "message_type": 0,
  "attachments": [{"filename": "", "content_type": "", "url": "", "size": 0}],
  "attachment_only": false,
  "full_message": true,            // 仅群全量消息
  "msg_elements": [...],           // 仅引用消息
  "message_reference": {"message_id": "..."},   // 仅引用消息
  "asr_text": "转写文本或 null",    // 仅含语音附件时
  "asr_note": "无转写时的原因",     // 仅转写失败/不可用时
  "received_at": "ISO 时间"
}
```

### outbox 格式（被动回复，与 inbox 文件同名）

```json
{"reply": "文本，可为空（纯媒体时）", "markdown": false,
 "media": [{"kind": "image|video|voice|file", "path": "本地文件绝对路径"}]}
```

`{"reply": "..."}` 的旧格式继续兼容。media 的 path 必须是已存在的本地
文件，否则整份 payload 按 INVALID 归档。

### proactive 格式（主动消息，任意文件名）

```json
{"scene": "c2c|group", "target": "用户或群 openid", "content": "文本",
 "markdown": false, "media": [{"kind": "image", "path": "..."}]}
```

## 凭据

机器人已在 QQ 开放平台创建（已扫码绑定）。凭据在
`~/workspace/qq-bridge/credentials.env`（格式见 `credentials.env.example`）：

```
QQBOT_APP_ID=<你的 AppID>
QQBOT_APP_SECRET=<你的 AppSecret>
```

文件权限 600。也可以直接在进程环境里导出这两个环境变量（环境变量
优先于文件）。没有凭据时守护进程会打印 `credentials missing` 并以
退出码 2 退出；看门狗在凭据文件缺失时静默不动作。

平台侧确认：应用需开通「群与 C2C 消息」相关事件订阅
（`C2C_MESSAGE_CREATE` / `GROUP_AT_MESSAGE_CREATE`，intent
`GROUP_MESSAGES`，SDK 默认已带）。群全量消息另需在平台给机器人开
「群全量消息」权限。

## 启动

当前运行方式（nohup + 看门狗保活）：

```bash
cd ~/workspace/qq-bridge && nohup .venv/bin/python daemon.py >> logs/daemon-stdout.log 2>&1 &
```

日志里出现 `gateway READY` 即已连上。systemd 用户服务文件也已备好
（`~/.config/systemd/user/qq-bridge.service`），但搭建时这台 VM 的
shell 里连不上 user systemd 总线（`systemctl --user` 报
No medium found），暂未启用；有用户会话时可改用
`systemctl --user enable --now qq-bridge.service`。

离线自检（不联网、不用凭据）：

```bash
~/workspace/qq-bridge/.venv/bin/python ~/workspace/qq-bridge/tests/test_bridge_offline.py
```

## 关键约束：5 分钟回复窗口

QQ 的被动回复只在原消息发出后 **5 分钟**内有效（守护进程以自身收到
消息的时刻 `received_at` 计时）。超时才写出的回复不会被发送：守护进程
会打日志 `reply for <msg_id> expired`，并把文件归档到 `done/` 加
`.EXPIRED` 标记。所以 agent 回合必须尽快产出回复；hook 的唤醒间隔是
10 秒就是为此。

其他行为：

- 机器人自己发的消息会被忽略；重复投递按 msg_id 去重（网关层与
  daemon 层各一份）。
- 发送失败时守护进程会在窗口关闭前持续重试；窗口内没发出去的最终
  按 EXPIRED 归档。
- `outbox/` 里没有对应 inbox 记录的文件会被按 `.ORPHAN` 归档。

## SDK 限制（qqbot-agent-sdk 1.2.2，含证据）

1. **GROUP_MESSAGE_CREATE 不被 SDK 支持**：
   - `dto.py` 的 `EventType` 枚举只列了 READY / RESUMED /
     C2C_MESSAGE_CREATE / GROUP_AT_MESSAGE_CREATE / DIRECT_MESSAGE_CREATE /
     GUILD_MESSAGE_CREATE / GUILD_AT_MESSAGE_CREATE / INTERACTION_CREATE，
     没有 GROUP_MESSAGE_CREATE；`MESSAGE_EVENT_TYPES` 同样不含它。
   - `websocket.py` 的 `QQWebSocket._handle_dispatch` 只路由 READY、
     RESUMED、`MESSAGE_EVENT_TYPES` 与 `INTERACTION_EVENT_TYPES`，
     其余一律落到 `Unhandled dispatch` 的 debug 日志被丢弃——所以即使
     平台推来群全量消息，SDK 的回调也永远收不到。
   - 本桥的对策（不改 SDK 文件）：daemon 里把一个解析函数注册进
     `EventParser._EVENT_HANDLERS["GROUP_MESSAGE_CREATE"]`，并用
     `QQWebSocket` 子类覆写 `_handle_dispatch`，把该事件与生命周期
     事件经 SDK 自身的 `_dispatch_to_main` 机制转给回调。生命周期
     事件（FRIEND_ADD 等）在 SDK 枚举里同样缺失，走同一条子类通道。
2. **频道私信没有发送方法**：`QQApiClient` 只有 post_c2c/group/guild
   三个发送方法。本桥用 SDK 的通用 `request()` + `Route` 直调官方
   `POST /dms/{guild_id}/messages`。
3. **富媒体上传只支持 C2C/群**：`MediaUploader.upload` 对其他
   chat_type 直接抛 ValueError，SDK 也没有频道上传接口。故频道/私信
   场景下 media 被跳过（有日志），文字照常发送。
4. **语音全量转写需要外部条件**：SDK 的 STTPipeline 在未配置 STT
   引擎时只回退平台自带的 `asr_refer_text`；要引擎转写需设置环境变量
   `QQ_STT_API_KEY`（可选 `QQ_STT_BASE_URL` / `QQ_STT_MODEL`），且 silk
   解码依赖 `pilk`（当前未安装；系统有 ffmpeg）。未配置时语音消息的
   `asr_text` 可能为 null，原因会写在 `asr_note` 里。

## Image fetching: browser route (decided 2026-11-07)

Inbound image attachments arrive as CDN URLs on multimedia.nt.qq.com.cn. Those
URLs cannot be fetched over this VM's shell network path: through the egress
proxy the TLS handshake completes and then the response stalls at zero bytes
(curl, httpx, HTTP/1.1, HTTP/2, full browser header sets — all identical); direct
egress fails instantly; the SDK's own AttachmentDownloader fails the same way.
The stored URL is att.resolved_url verbatim, so URL handling is not the issue.
The live browser (Chromium, different egress route) loads the same URLs
instantly. Decision (user-approved 2026-11-07): the inbox wake-hook prompt now
tells workers to fetch image content ONLY via browser.browse — never curl —
and to compose the reply from the browser's description or a saved download.
Expected image-reply latency: ~1.5–3 min, inside the 5-min passive window.
