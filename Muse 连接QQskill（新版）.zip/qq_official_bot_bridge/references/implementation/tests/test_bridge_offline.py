#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Offline test suite for the qq-bridge daemon.

Runs the real daemon code against a stubbed QQ API client in a throwaway
QQ_BRIDGE_HOME.  No network, no credentials.  Each test prints PASS/FAIL
by name; the process exit code is non-zero when any test fails.

Run:  ~/workspace/qq-bridge/.venv/bin/python tests/test_bridge_offline.py
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
import tempfile
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

TEST_HOME = Path(tempfile.mkdtemp(prefix="qqbridge-test-"))
os.environ["QQ_BRIDGE_HOME"] = str(TEST_HOME)

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import daemon  # noqa: E402

for d in (daemon.INBOX, daemon.OUTBOX, daemon.PROACTIVE, daemon.EVENTS,
          daemon.DONE, daemon.LOGS, daemon.STATE):
    d.mkdir(parents=True, exist_ok=True)


# ── Stubs ─────────────────────────────────────────────────────────────

class StubAPI:
    """Records every call the daemon makes against the QQ API."""

    def __init__(self) -> None:
        self.text_calls: list = []
        self.typing_calls: list = []
        self.posted: list = []      # (kind, chat_id, body_dict)
        self.requests: list = []    # (path, body_dict)
        self.acks: list = []        # (interaction_id, code)

    async def send_text(self, chat_type, chat_id, content, *, reply_to=None,
                        markdown=True, **kwargs):
        self.text_calls.append({
            "chat_type": chat_type, "chat_id": chat_id, "content": content,
            "reply_to": reply_to, "markdown": markdown,
        })
        return {"id": "sent-text"}

    async def send_typing(self, chat_id, msg_id, **kwargs):
        self.typing_calls.append((chat_id, msg_id))

    async def post_c2c_message(self, user_id, msg):
        self.posted.append(("c2c", user_id, msg.to_dict()))
        return {"id": "sent-media"}

    async def post_group_message(self, group_id, msg):
        self.posted.append(("group", group_id, msg.to_dict()))
        return {"id": "sent-media"}

    async def request(self, route, body=None, **kwargs):
        path = getattr(route, "full_path", str(route))
        self.requests.append((path, body))
        return {}

    async def acknowledge_interaction(self, interaction_id, code=0, data=None):
        self.acks.append((interaction_id, code))


class StubUploader:
    def __init__(self) -> None:
        self.calls: list = []

    async def upload(self, chat_type, chat_id, source, file_type, file_name=None):
        self.calls.append({
            "chat_type": chat_type, "chat_id": chat_id, "source": source,
            "file_type": file_type, "file_name": file_name,
        })
        return "FILEINFO-TEST"


def make_bridge():
    api = StubAPI()
    # http_client=object(): enough to construct the SDK helpers; with no
    # STT engine configured the transcription path never touches it.
    bridge = daemon.Bridge("test-app-id", api, http_client=object())
    return bridge, api


def write_json(path: Path, payload: dict) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")


def inbox_record(msg_id: str) -> dict:
    return json.loads((daemon.INBOX / f"{msg_id}.json").read_text(encoding="utf-8"))


def fresh_record(msg_id: str, scene: str, chat_id: str, **extra) -> dict:
    rec = {
        "msg_id": msg_id,
        "scene": scene,
        "user_openid": extra.pop("user_openid", "U1"),
        "group_openid": extra.pop("group_openid", None),
        "channel_id": extra.pop("channel_id", None),
        "chat_id": chat_id,
        "content": "hi",
        "received_at": datetime.now(timezone.utc).isoformat(),
    }
    rec.update(extra)
    return rec


# ── Tests ─────────────────────────────────────────────────────────────

async def test_attachment_only_message_lands_in_inbox():
    bridge, _ = make_bridge()
    raw = {
        "id": "t-att-1",
        "content": "",
        "author": {"user_openid": "U1", "bot": False},
        "attachments": [{
            "url": "//cdn.example.com/a.jpg", "filename": "a.jpg",
            "content_type": "image/jpeg", "size": 123, "width": 10, "height": 20,
        }],
    }
    await bridge.on_message_event("C2C_MESSAGE_CREATE", raw)
    rec = inbox_record("t-att-1")
    assert rec["attachment_only"] is True, rec
    assert rec["content"] == ""
    att = rec["attachments"][0]
    assert att["filename"] == "a.jpg" and att["content_type"] == "image/jpeg"
    assert att["size"] == 123 and att["width"] == 10 and att["height"] == 20
    assert att["url"].startswith("https://"), att


async def test_voice_record_with_platform_asr():
    bridge, _ = make_bridge()
    raw = {
        "id": "t-voice-1",
        "content": "",
        "author": {"user_openid": "U1", "bot": False},
        "attachments": [{
            "url": "https://cdn.example.com/v.silk", "filename": "v.silk",
            "content_type": "audio/silk", "size": 42,
            "asr_refer_text": "你好世界",
        }],
    }
    await bridge.on_message_event("C2C_MESSAGE_CREATE", raw)
    rec = inbox_record("t-voice-1")
    # Real SDK STTPipeline: no engine configured → platform asr_refer_text.
    assert rec["asr_text"] == "你好世界", rec
    assert "asr_note" not in rec


async def test_voice_record_without_asr():
    bridge, _ = make_bridge()
    raw = {
        "id": "t-voice-2",
        "content": "",
        "author": {"user_openid": "U1", "bot": False},
        "attachments": [{
            "url": "https://cdn.example.com/v.silk", "filename": "v.silk",
            "content_type": "audio/silk", "size": 42,
        }],
    }
    await bridge.on_message_event("C2C_MESSAGE_CREATE", raw)
    rec = inbox_record("t-voice-2")
    assert rec["asr_text"] is None, rec
    assert "no STT engine configured" in rec["asr_note"], rec
    assert rec["attachments"][0]["content_type"] == "audio/silk"


async def test_guild_record_and_reply_route():
    bridge, api = make_bridge()
    raw = {
        "id": "t-guild-1", "channel_id": "CH1", "guild_id": "G1",
        "content": "hello guild",
        "author": {"id": "GU1", "username": "nick", "bot": False},
        "member": {"nick": "Nick"},
    }
    await bridge.on_message_event("GUILD_AT_MESSAGE_CREATE", raw)
    rec = inbox_record("t-guild-1")
    assert rec["scene"] == "guild" and rec["chat_id"] == "CH1", rec
    write_json(daemon.OUTBOX / "t-guild-1.json", {"reply": "hi channel"})
    await bridge._handle_outbox_file(daemon.OUTBOX / "t-guild-1.json")
    call = api.text_calls[-1]
    assert call["chat_type"] == "guild" and call["chat_id"] == "CH1", call
    assert call["reply_to"] == "t-guild-1"
    assert (daemon.DONE / "t-guild-1.SENT").exists()


async def test_dm_record_and_reply_route():
    bridge, api = make_bridge()
    raw = {
        "id": "t-dm-1", "guild_id": "DMG1", "content": "hi dm",
        "author": {"id": "GU2", "bot": False}, "direct_message": True,
    }
    await bridge.on_message_event("DIRECT_MESSAGE_CREATE", raw)
    rec = inbox_record("t-dm-1")
    assert rec["scene"] == "dm" and rec["chat_id"] == "DMG1", rec
    write_json(daemon.OUTBOX / "t-dm-1.json", {"reply": "hi back"})
    await bridge._handle_outbox_file(daemon.OUTBOX / "t-dm-1.json")
    assert api.requests, "expected a /dms request"
    path, body = api.requests[-1]
    assert path == "/dms/DMG1/messages", path
    assert body["content"] == "hi back" and body["msg_id"] == "t-dm-1", body
    assert (daemon.DONE / "t-dm-1.SENT").exists()


async def test_group_full_message_custom_handler():
    bridge, _ = make_bridge()
    raw = {
        "id": "t-full-1", "group_openid": "GRP1",
        "content": "a full group message, no @ needed",
        "author": {"member_openid": "MB1", "bot": False},
        "attachments": [],
    }
    event = bridge.parser.parse("GROUP_MESSAGE_CREATE", raw)
    assert event is not None, "custom parser handler returned None"
    assert event.chat_scope == "group" and event.chat_id == "GRP1"
    await bridge.on_message_event("GROUP_MESSAGE_CREATE", raw)
    rec = inbox_record("t-full-1")
    assert rec["full_message"] is True and rec["scene"] == "group", rec
    assert rec["group_openid"] == "GRP1" and rec["user_openid"] == "MB1"


async def test_interaction_acknowledged_and_logged():
    bridge, api = make_bridge()
    raw = {
        "id": "INT1", "type": 11, "chat_type": 2, "scene": "c2c",
        "user_openid": "U1",
        "data": {"type": 1, "resolved": {
            "button_data": "x", "button_id": "b1", "user_id": "U1",
        }},
    }
    await bridge.on_interaction_event("INTERACTION_CREATE", raw)
    assert api.acks == [("INT1", 0)], api.acks
    lines = (daemon.EVENTS / "events.jsonl").read_text(encoding="utf-8").splitlines()
    entries = [json.loads(l) for l in lines]
    assert any(e["type"] == "INTERACTION_CREATE" and e["interaction_id"] == "INT1"
               for e in entries), entries


async def test_lifecycle_event_logged():
    bridge, _ = make_bridge()
    await bridge.on_lifecycle_event("FRIEND_ADD", {
        "user_openid": "U9", "timestamp": "2026-11-07T14:00:00+08:00",
    })
    lines = (daemon.EVENTS / "events.jsonl").read_text(encoding="utf-8").splitlines()
    entries = [json.loads(l) for l in lines]
    assert any(e["type"] == "FRIEND_ADD" and e["ids"].get("user_openid") == "U9"
               for e in entries), entries


async def test_markdown_outbox():
    bridge, api = make_bridge()
    write_json(daemon.INBOX / "t-md-1.json",
               fresh_record("t-md-1", "c2c", "U1"))
    write_json(daemon.OUTBOX / "t-md-1.json",
               {"reply": "**bold**", "markdown": True})
    await bridge._handle_outbox_file(daemon.OUTBOX / "t-md-1.json")
    call = api.text_calls[-1]
    assert call["markdown"] is True and call["content"] == "**bold**", call
    assert (daemon.DONE / "t-md-1.SENT").exists()


async def test_media_outbox_uploads_and_sends_rich():
    bridge, api = make_bridge()
    bridge.uploader = StubUploader()
    img = TEST_HOME / "pic.jpg"
    img.write_bytes(b"\xff\xd8\xff\xe0fake-jpeg")
    write_json(daemon.INBOX / "t-media-1.json",
               fresh_record("t-media-1", "c2c", "U1"))
    write_json(daemon.OUTBOX / "t-media-1.json", {
        "reply": "看图",
        "media": [{"kind": "image", "path": str(img)}],
    })
    await bridge._handle_outbox_file(daemon.OUTBOX / "t-media-1.json")
    assert bridge.uploader.calls and bridge.uploader.calls[0]["file_type"] == 1
    assert api.posted, "expected a rich-media post"
    kind, chat_id, body = api.posted[-1]
    assert kind == "c2c" and chat_id == "U1", (kind, chat_id)
    assert body["msg_type"] == 7, body
    assert body["media"]["file_info"] == "FILEINFO-TEST", body
    assert body["content"] == "看图", body
    assert (daemon.DONE / "t-media-1.SENT").exists()


async def test_typing_on_c2c_intake():
    bridge, api = make_bridge()
    raw = {
        "id": "t-type-1", "content": "在吗",
        "author": {"user_openid": "U1", "bot": False},
    }
    await bridge.on_message_event("C2C_MESSAGE_CREATE", raw)
    await asyncio.sleep(0.1)  # let the fire-and-forget typing task run
    assert ("U1", "t-type-1") in api.typing_calls, api.typing_calls


async def test_proactive_sends_without_msg_id():
    bridge, api = make_bridge()
    write_json(daemon.PROACTIVE / "p1.json", {
        "scene": "c2c", "target": "U1", "content": "主动消息", "markdown": False,
    })
    await bridge._handle_proactive_file(daemon.PROACTIVE / "p1.json")
    call = api.text_calls[-1]
    assert call["chat_type"] == "c2c" and call["chat_id"] == "U1", call
    assert call["reply_to"] is None, call  # no msg_id → proactive send
    assert (daemon.DONE / "p1.SENT").exists()
    assert (daemon.DONE / "p1.proactive.json").exists()


async def test_plain_reply_still_works():
    bridge, api = make_bridge()
    write_json(daemon.INBOX / "t-plain-1.json",
               fresh_record("t-plain-1", "c2c", "U1"))
    write_json(daemon.OUTBOX / "t-plain-1.json", {"reply": "纯文本回复"})
    await bridge._handle_outbox_file(daemon.OUTBOX / "t-plain-1.json")
    call = api.text_calls[-1]
    assert call["markdown"] is False and call["content"] == "纯文本回复", call
    assert call["reply_to"] == "t-plain-1"
    assert (daemon.DONE / "t-plain-1.SENT").exists()


async def test_expired_reply_not_sent():
    bridge, api = make_bridge()
    old = (datetime.now(timezone.utc) - timedelta(seconds=600)).isoformat()
    write_json(daemon.INBOX / "t-old-1.json",
               fresh_record("t-old-1", "c2c", "U1", received_at=old))
    write_json(daemon.OUTBOX / "t-old-1.json", {"reply": "太晚了"})
    before = len(api.text_calls)
    await bridge._handle_outbox_file(daemon.OUTBOX / "t-old-1.json")
    assert len(api.text_calls) == before, "expired reply must not be sent"
    assert (daemon.DONE / "t-old-1.EXPIRED").exists()


TESTS = [
    ("attachment_only_message_lands_in_inbox", test_attachment_only_message_lands_in_inbox),
    ("voice_record_with_platform_asr", test_voice_record_with_platform_asr),
    ("voice_record_without_asr", test_voice_record_without_asr),
    ("guild_record_and_reply_route", test_guild_record_and_reply_route),
    ("dm_record_and_reply_route", test_dm_record_and_reply_route),
    ("group_full_message_custom_handler", test_group_full_message_custom_handler),
    ("interaction_acknowledged_and_logged", test_interaction_acknowledged_and_logged),
    ("lifecycle_event_logged", test_lifecycle_event_logged),
    ("markdown_outbox", test_markdown_outbox),
    ("media_outbox_uploads_and_sends_rich", test_media_outbox_uploads_and_sends_rich),
    ("typing_on_c2c_intake", test_typing_on_c2c_intake),
    ("proactive_sends_without_msg_id", test_proactive_sends_without_msg_id),
    ("plain_reply_still_works", test_plain_reply_still_works),
    ("expired_reply_not_sent", test_expired_reply_not_sent),
]


async def main() -> int:
    started = time.time()
    failures = 0
    for name, fn in TESTS:
        try:
            await fn()
        except Exception as exc:  # noqa: BLE001 - report and continue
            failures += 1
            print(f"FAIL {name}: {type(exc).__name__}: {exc}")
        else:
            print(f"PASS {name}")
    print(f"\n{len(TESTS) - failures}/{len(TESTS)} passed in {time.time() - started:.1f}s")
    print(f"test home: {TEST_HOME}")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
