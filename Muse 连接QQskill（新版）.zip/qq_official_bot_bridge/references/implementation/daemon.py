#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""qq-bridge daemon: official QQ Bot <-> file inbox/outbox <-> Muse (Lora).

Inbound : QQ messages received through Tencent's official qqbot-agent-sdk
          (WebSocket Gateway + OpenAPI v2) are written as JSON files to
          inbox/.  Covered scenes: C2C private chat, group @ messages,
          group full messages (GROUP_MESSAGE_CREATE), guild (channel)
          messages and channel DMs.  Attachments (image / video / file /
          voice) are recorded alongside the text; voice attachments are
          run through the SDK's STT pipeline (which falls back to the
          platform-provided ``asr_refer_text``) and the transcript is
          stored as ``asr_text``.  Interaction and lifecycle events are
          acknowledged (interactions) and appended to events/events.jsonl;
          they never enter the inbox.
Outbound: a watcher polls outbox/ every ~3s.  When outbox/<msg_id>.json
          appears, its reply is sent as a passive reply (msg_id reference)
          via the official API.  The payload contract is
          ``{"reply": "..."}`` (plain text), optionally extended with
          ``"markdown": true`` and/or ``"media": [{"kind": ..., "path":
          ...}]`` for rich media (msg_type 7).  A second watcher polls
          proactive/ for proactive (non-reply) messages.  Handled files
          are archived under done/ with a result marker.

QQ passive replies are only accepted within 5 minutes of the original
message; a reply that arrives later is logged as expired and archived
with an EXPIRED marker instead of being sent.

Credentials come from the environment variables QQBOT_APP_ID and
QQBOT_APP_SECRET, optionally loaded from credentials.env in the bridge
directory. The secret is never written to the log.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import signal
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

# httpx chokes on bracketed IPv6 entries in NO_PROXY (e.g. "[::1]") when it
# builds proxy mounts; the QQ endpoints go through the egress proxy anyway,
# so trim NO_PROXY down to plain hostnames/IPv4 entries for this process.
for _key in ("NO_PROXY", "no_proxy"):
    _raw = os.environ.get(_key)
    if _raw:
        _kept = [p.strip() for p in _raw.split(",") if p.strip() and ":" not in p and "[" not in p]
        os.environ[_key] = ",".join(_kept) if _kept else "localhost"

import httpx
from qqbot_agent_sdk import (
    EventParser,
    InboundEvent,
    MAX_MESSAGE_LENGTH,
    MEDIA_TYPE_FILE,
    MEDIA_TYPE_IMAGE,
    MEDIA_TYPE_VIDEO,
    MEDIA_TYPE_VOICE,
    QQApiClient,
    QQMessageType,
    QQWebSocket,
    WSCallbacks,
    WSSessionStore,
    is_voice_content_type,
    parse_interaction_event,
    resolve_stt_config,
)
from qqbot_agent_sdk.api_client import Route
from qqbot_agent_sdk.attachment import AttachmentDownloader
from qqbot_agent_sdk.audio import STTPipeline
from qqbot_agent_sdk.dto import GuildMessageToCreate, MediaInfo, MessageToCreate
from qqbot_agent_sdk.media_loader import MediaUploader

BASE = Path(os.environ.get("QQ_BRIDGE_HOME", Path(__file__).resolve().parent))
INBOX = BASE / "inbox"
OUTBOX = BASE / "outbox"
PROACTIVE = BASE / "proactive"
EVENTS = BASE / "events"
DONE = BASE / "done"
LOGS = BASE / "logs"
STATE = BASE / "state"
CREDENTIALS_FILE = Path(
    os.environ.get("QQ_BRIDGE_CREDENTIALS", str(BASE / "credentials.env"))
)

REPLY_WINDOW_SECONDS = 300  # QQ passive-reply window: 5 minutes
OUTBOX_POLL_SECONDS = 3.0
ASR_TIMEOUT_SECONDS = 25.0

MEDIA_KIND_TO_TYPE = {
    "image": MEDIA_TYPE_IMAGE,
    "video": MEDIA_TYPE_VIDEO,
    "voice": MEDIA_TYPE_VOICE,
    "file": MEDIA_TYPE_FILE,
}

# Lifecycle / relation events: logged to events.jsonl, never answered.
LIFECYCLE_EVENT_TYPES = frozenset({
    "FRIEND_ADD",
    "FRIEND_DEL",
    "GROUP_ADD_ROBOT",
    "GROUP_DEL_ROBOT",
    "GROUP_MSG_REJECT",
    "GROUP_MSG_RECEIVE",
    "C2C_MSG_REJECT",
    "C2C_MSG_RECEIVE",
})

logger = logging.getLogger("qq-bridge")


# ── GROUP_MESSAGE_CREATE support ─────────────────────────────────────
#
# The SDK's EventParser has no handler for GROUP_MESSAGE_CREATE (group
# full messages) and its dto.EventType does not list the event at all, so
# we register a handler into EventParser._EVENT_HANDLERS from here (the
# SDK files themselves are not modified).  The payload shape matches
# GROUP_AT_MESSAGE_CREATE (group_openid / author.member_openid /
# attachments); the content is kept as delivered — a full message was
# not necessarily addressed to the bot, so no leading @mention is
# stripped.

def _parse_group_full_message(
    event_type: str,
    msg: Any,
    content: str,
    raw: dict,
) -> Optional[InboundEvent]:
    if not msg.group_openid:
        return None
    return InboundEvent(
        event_type=event_type,
        chat_id=msg.group_openid,
        user_id=msg.author.member_openid,
        chat_scope="group",
        content=content,
        message_id=msg.id,
        timestamp=msg.timestamp,
        message_type=msg.message_type,
        attachments=msg.attachments,
        msg_elements=msg.msg_elements,
        raw=raw,
    )


EventParser._EVENT_HANDLERS["GROUP_MESSAGE_CREATE"] = _parse_group_full_message


class BridgeWebSocket(QQWebSocket):
    """QQWebSocket plus dispatch for events the SDK drops.

    The SDK's ``_handle_dispatch`` only routes READY/RESUMED, the five
    MESSAGE_EVENT_TYPES and INTERACTION_CREATE; every other dispatch is
    logged at debug level and discarded.  GROUP_MESSAGE_CREATE and the
    lifecycle events therefore never reach the host callbacks.  This
    subclass (SDK files untouched) routes them through the same
    ``_dispatch_to_main`` mechanism the SDK itself uses.
    """

    lifecycle_handler: Optional[Any] = None  # async (event_type, data)

    def _handle_dispatch(self, event_type: str, data: dict) -> None:
        if event_type == "GROUP_MESSAGE_CREATE":
            msg_id = str(data.get("id", ""))
            if msg_id and self._is_duplicate(msg_id):
                logger.debug("duplicate group full message dropped: %s", msg_id)
                return
            self._dispatch_to_main(self._cb.on_message_event(event_type, data))
            return
        if event_type in LIFECYCLE_EVENT_TYPES and self.lifecycle_handler is not None:
            self._dispatch_to_main(self.lifecycle_handler(event_type, data))
            return
        super()._handle_dispatch(event_type, data)


def setup_logging() -> None:
    LOGS.mkdir(parents=True, exist_ok=True)
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
    file_handler = logging.FileHandler(LOGS / "daemon.log", encoding="utf-8")
    file_handler.setFormatter(fmt)
    stream_handler = logging.StreamHandler(sys.stderr)
    stream_handler.setFormatter(fmt)
    logging.basicConfig(level=logging.INFO, handlers=[file_handler, stream_handler])


def load_credentials() -> Optional[tuple]:
    """Return (app_id, secret) or None when either is missing.

    Values already present in the process environment win; the rest are
    read from the credentials env file (simple KEY=VALUE lines).
    """
    if CREDENTIALS_FILE.is_file():
        for line in CREDENTIALS_FILE.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, value = line.partition("=")
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            if key and key not in os.environ:
                os.environ[key] = value
    app_id = os.environ.get("QQBOT_APP_ID", "").strip()
    secret = os.environ.get("QQBOT_APP_SECRET", "").strip()
    if not app_id or not secret:
        return None
    return app_id, secret


def _parse_iso(value: str) -> Optional[float]:
    """Parse an ISO-8601 timestamp to epoch seconds (None when invalid)."""
    try:
        dt = datetime.fromisoformat(value)
    except (TypeError, ValueError):
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.timestamp()


def _attachment_dict(att: Any) -> dict:
    """Serialize an SDK MessageAttachment for the inbox record."""
    d: dict = {
        "filename": att.filename or "",
        "content_type": att.content_type or "",
        "url": att.resolved_url or "",
        "size": att.size or 0,
    }
    if att.width:
        d["width"] = att.width
    if att.height:
        d["height"] = att.height
    if att.voice_wav_url:
        d["voice_wav_url"] = att.voice_wav_url
    return d


class Bridge:
    """Holds bridge state and implements the SDK callbacks."""

    def __init__(
        self,
        app_id: str,
        api: QQApiClient,
        http_client: Optional[Any] = None,
    ) -> None:
        self.app_id = app_id
        self.api = api
        self.parser = EventParser()
        self.bot_openids: set = set()
        self.session_store = WSSessionStore(
            base_dir=str(STATE), filename="ws_session.json"
        )
        # Media upload + voice transcription helpers (SDK-provided).
        self.uploader: Optional[MediaUploader] = None
        self.stt: Optional[STTPipeline] = None
        self.stt_configured = resolve_stt_config({}) is not None
        if http_client is not None:
            self.uploader = MediaUploader(api, http_client, log_tag="QQBridge")
            downloader = AttachmentDownloader(
                http_client,
                cache_dir=str(STATE / "attachments"),
                log_tag="QQBridge",
            )
            self.stt = STTPipeline(
                http_client,
                lambda: resolve_stt_config({}),
                downloader,
                log_tag="QQBridge",
            )

    # -- gateway callbacks ---------------------------------------------

    def on_ready(self, ready: Any) -> None:
        user = getattr(ready, "user", None)
        if user is not None:
            for value in (getattr(user, "id", ""), getattr(user, "user_openid", "")):
                if value:
                    self.bot_openids.add(str(value))
        logger.info(
            "gateway READY; bot identity captured (%d id(s))", len(self.bot_openids)
        )

    def get_session(self):
        session = self.session_store.get(self.app_id)
        if session.is_resumable and session.is_fresh():
            return (session.session_id, session.seq)
        return (None, None)

    def set_session(self, session_id: Optional[str], seq: Optional[int]) -> None:
        if session_id:
            self.session_store.save(self.app_id, session_id, seq)

    # -- event log (interactions + lifecycle) ---------------------------

    def _append_event(self, entry: dict) -> None:
        EVENTS.mkdir(parents=True, exist_ok=True)
        with (EVENTS / "events.jsonl").open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(entry, ensure_ascii=False) + "\n")

    @staticmethod
    def _extract_ids(raw: dict) -> dict:
        ids: dict = {}
        for key in (
            "id",
            "user_openid",
            "member_openid",
            "group_openid",
            "group_member_openid",
            "operator_openid",
            "channel_id",
            "guild_id",
        ):
            value = raw.get(key)
            if value:
                ids[key] = str(value)
        return ids

    async def on_interaction_event(self, event_type: str, raw: dict) -> None:
        """Acknowledge a button interaction and log it; never answered."""
        try:
            event = parse_interaction_event(raw)
        except Exception:
            logger.exception("failed to parse interaction event")
            return
        if event.id:
            try:
                await self.api.acknowledge_interaction(event.id, code=0)
            except Exception:
                logger.exception("failed to acknowledge interaction %s", event.id)
        self._append_event({
            "type": event_type,
            "interaction_id": event.id,
            "scene": event.scene,
            "ids": self._extract_ids(raw),
            "timestamp": raw.get("timestamp"),
            "received_at": datetime.now(timezone.utc).isoformat(),
        })
        logger.info("interaction %s acknowledged (scene %s)", event.id, event.scene)

    async def on_lifecycle_event(self, event_type: str, raw: dict) -> None:
        """Append a lifecycle/relation event to events.jsonl."""
        self._append_event({
            "type": event_type,
            "ids": self._extract_ids(raw),
            "timestamp": raw.get("timestamp"),
            "received_at": datetime.now(timezone.utc).isoformat(),
        })
        logger.info("lifecycle event logged: %s", event_type)

    # -- inbound --------------------------------------------------------

    async def _transcribe_voice(self, att: Any) -> tuple:
        """Return (asr_text, asr_note) for a voice attachment.

        Uses the SDK STTPipeline: a configured STT engine when available,
        otherwise the platform-provided ``asr_refer_text`` carried by the
        event itself.  Nothing is invented — when neither source yields
        text, asr_text is None and the note says why.
        """
        if self.stt is None:
            return None, "asr unavailable: transcription pipeline not initialised"
        try:
            text = await asyncio.wait_for(
                self.stt.transcribe(att), timeout=ASR_TIMEOUT_SECONDS
            )
        except Exception:
            logger.exception("voice transcription failed")
            return None, "asr failed: transcription pipeline error (see daemon log)"
        if text:
            return text, None
        if self.stt_configured:
            return None, "asr produced no text: STT engine and platform asr_refer_text both empty"
        return None, (
            "asr produced no text: no STT engine configured "
            "(set QQ_STT_API_KEY to enable one) and platform asr_refer_text was empty"
        )

    async def on_message_event(self, event_type: str, raw: dict) -> None:
        try:
            event = self.parser.parse(event_type, raw)
        except Exception:
            logger.exception("failed to parse event %s", event_type)
            return
        if event is None or event.chat_scope not in ("c2c", "group", "guild", "dm"):
            return
        author = raw.get("author") or {}
        if author.get("bot"):
            return  # never react to bots, including ourselves
        sender = str(event.user_id or "")
        if sender and sender in self.bot_openids:
            return  # our own message echoed back
        content = (event.content or "").strip()
        attachments = [_attachment_dict(att) for att in event.attachments]
        if not content and not attachments and not event.msg_elements:
            return  # genuinely empty message — nothing to hand to the agent
        msg_id = event.message_id
        if not msg_id or "/" in msg_id or "\\" in msg_id or msg_id in (".", ".."):
            logger.warning("dropping message with unsafe id %r", msg_id)
            return
        target = INBOX / f"{msg_id}.json"
        if target.exists() or (DONE / f"{msg_id}.json").exists():
            return  # duplicate delivery
        record: dict = {
            "msg_id": msg_id,
            "scene": event.chat_scope,
            "event_type": event_type,
            "user_openid": sender,
            "group_openid": event.chat_id if event.chat_scope == "group" else None,
            "channel_id": event.chat_id if event.chat_scope == "guild" else None,
            "chat_id": event.chat_id,
            "content": content,
            "message_type": event.message_type,
            "attachments": attachments,
            "attachment_only": not content and bool(attachments),
            "received_at": datetime.now(timezone.utc).isoformat(),
        }
        if event_type == "GROUP_MESSAGE_CREATE":
            record["full_message"] = True
        if event.msg_elements:
            record["msg_elements"] = [
                {
                    "content": el.content or "",
                    "attachments": [_attachment_dict(a) for a in el.attachments],
                }
                for el in event.msg_elements
            ]
        reference = raw.get("message_reference")
        if isinstance(reference, dict) and reference.get("message_id"):
            record["message_reference"] = {
                "message_id": str(reference["message_id"])
            }
        # Voice: transcribe the first voice attachment, if any.
        for att in event.attachments:
            if is_voice_content_type(att.content_type or "", att.filename or ""):
                asr_text, asr_note = await self._transcribe_voice(att)
                record["asr_text"] = asr_text
                if asr_note:
                    record["asr_note"] = asr_note
                break
        tmp = INBOX / f".{msg_id}.tmp"
        tmp.write_text(
            json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        tmp.rename(target)
        logger.info(
            "inbox: %s message %s from %s (%d chars, %d attachment(s))",
            record["scene"],
            msg_id,
            sender,
            len(content),
            len(attachments),
        )
        if event.chat_scope == "c2c":
            asyncio.create_task(self._send_typing(sender, msg_id))

    async def _send_typing(self, user_openid: str, msg_id: str) -> None:
        """Best-effort typing indicator for C2C conversations."""
        try:
            await self.api.send_typing(user_openid, msg_id)
        except Exception:
            logger.debug("send_typing failed for %s", msg_id, exc_info=True)

    # -- outbound -------------------------------------------------------

    async def _send_text_message(
        self,
        scene: str,
        chat_id: str,
        text: str,
        *,
        reply_to: Optional[str],
        markdown: bool,
    ) -> None:
        """Send a text/markdown message for any scene.

        C2C / group / guild go through the SDK's send_text; channel DMs
        have no dedicated client method, so they use the SDK's generic
        authenticated request with the official /dms route.
        """
        if scene == "dm":
            body = GuildMessageToCreate(
                content=text[:MAX_MESSAGE_LENGTH],
                msg_id=reply_to or "",
            )
            route = Route(
                "POST", "/dms/{guild_id}/messages", guild_id=chat_id
            )
            await self.api.request(route, body.to_dict())
            return
        await self.api.send_text(
            scene, chat_id, text, reply_to=reply_to, markdown=markdown
        )

    async def _upload_media(self, scene: str, chat_id: str, item: dict) -> str:
        """Upload one local media file via the SDK; returns file_info."""
        kind = str(item.get("kind") or "")
        if kind not in MEDIA_KIND_TO_TYPE:
            raise ValueError(f"unknown media kind: {kind!r}")
        path = Path(str(item.get("path") or ""))
        if self.uploader is None:
            raise RuntimeError("media uploader unavailable (no http client)")
        return await self.uploader.upload(
            scene, chat_id, str(path), MEDIA_KIND_TO_TYPE[kind], path.name
        )

    async def _send_media_message(
        self,
        scene: str,
        chat_id: str,
        file_info: str,
        *,
        text: str,
        reply_to: Optional[str],
    ) -> None:
        """Send one rich-media (msg_type 7) message for C2C/group."""
        msg = MessageToCreate(
            msg_type=int(QQMessageType.RICH_MEDIA),
            msg_seq=QQApiClient.next_msg_seq(),
            msg_id=reply_to or "",
            media=MediaInfo(file_info=file_info),
        )
        if text:
            msg.content = text[:MAX_MESSAGE_LENGTH]
        if scene == "c2c":
            await self.api.post_c2c_message(chat_id, msg)
        elif scene == "group":
            await self.api.post_group_message(chat_id, msg)
        else:
            raise RuntimeError(f"rich media not supported for scene {scene!r}")

    @staticmethod
    def _validated_media(payload: dict) -> Optional[list]:
        """Return the payload's media list, or None if any entry is bad.

        Every entry must name a known kind and a local file that exists;
        a bad entry makes the whole payload unsendable (archived INVALID
        by the caller) rather than retrying forever.
        """
        media = payload.get("media") or []
        if not isinstance(media, list):
            return None
        for item in media:
            if not isinstance(item, dict):
                return None
            if str(item.get("kind") or "") not in MEDIA_KIND_TO_TYPE:
                return None
            path = Path(str(item.get("path") or ""))
            if not path.is_file():
                return None
        return media

    async def _deliver(
        self,
        scene: str,
        chat_id: str,
        *,
        text: str,
        markdown: bool,
        media: list,
        reply_to: Optional[str],
    ) -> bool:
        """Send text and/or media; returns True when anything was sent.

        Rich media is supported for C2C/group only.  For guild/dm the
        media entries are skipped with a log line and the text (if any)
        still goes out.  When both text and media are present for
        C2C/group, the text rides along with the first media message.
        """
        media_sendable = media if scene in ("c2c", "group") else []
        if media and not media_sendable:
            logger.warning(
                "media skipped for scene %s (SDK upload supports c2c/group only)",
                scene,
            )
        sent = False
        for idx, item in enumerate(media_sendable):
            file_info = await self._upload_media(scene, chat_id, item)
            await self._send_media_message(
                scene,
                chat_id,
                file_info,
                text=text if idx == 0 else "",
                reply_to=reply_to,
            )
            sent = True
        if text and not media_sendable:
            await self._send_text_message(
                scene, chat_id, text, reply_to=reply_to, markdown=markdown
            )
            sent = True
        return sent

    async def outbox_loop(self) -> None:
        while True:
            try:
                for path in sorted(p for p in OUTBOX.glob("*.json") if not p.name.startswith(".")):
                    await self._handle_outbox_file(path)
            except Exception:
                logger.exception("outbox scan failed")
            await asyncio.sleep(OUTBOX_POLL_SECONDS)

    async def _handle_outbox_file(self, path: Path) -> None:
        msg_id = path.stem
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return  # still being written; retry on the next poll
        inbox_file = INBOX / f"{msg_id}.json"
        if not inbox_file.exists():
            logger.warning(
                "outbox %s has no matching inbox record; archiving as orphan",
                msg_id,
            )
            self._archive(msg_id, "ORPHAN")
            return
        try:
            record = json.loads(inbox_file.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            logger.exception("inbox record %s unreadable", msg_id)
            return
        received_ts = _parse_iso(str(record.get("received_at", "")))
        age = time.time() - received_ts if received_ts is not None else float("inf")
        if age > REPLY_WINDOW_SECONDS:
            logger.warning(
                "reply for %s expired (age %.0fs > %ds); not sent",
                msg_id,
                age,
                REPLY_WINDOW_SECONDS,
            )
            self._archive(msg_id, "EXPIRED")
            return
        reply = str(payload.get("reply") or "").strip()
        markdown = bool(payload.get("markdown"))
        media = self._validated_media(payload)
        if media is None:
            logger.warning("outbox %s has invalid media entries; archiving", msg_id)
            self._archive(msg_id, "INVALID")
            return
        if not reply and not media:
            logger.warning("outbox %s has an empty reply; archiving as invalid", msg_id)
            self._archive(msg_id, "INVALID")
            return
        scene = str(record.get("scene") or "c2c")
        chat_id = (
            record.get("chat_id")
            or record.get("group_openid")
            or record.get("user_openid")
        )
        try:
            sent = await self._deliver(
                scene,
                str(chat_id),
                text=reply,
                markdown=markdown,
                media=media,
                reply_to=msg_id,
            )
        except Exception:
            logger.exception(
                "send failed for %s; will retry until the reply window closes",
                msg_id,
            )
            return
        if not sent:
            logger.warning(
                "outbox %s had nothing sendable for scene %s; archiving as invalid",
                msg_id,
                scene,
            )
            self._archive(msg_id, "INVALID")
            return
        logger.info("sent reply for %s (%d chars, %d media)", msg_id, len(reply), len(media))
        self._archive(msg_id, "SENT")

    def _archive(self, msg_id: str, marker: str) -> None:
        DONE.mkdir(parents=True, exist_ok=True)
        inbox_file = INBOX / f"{msg_id}.json"
        outbox_file = OUTBOX / f"{msg_id}.json"
        if inbox_file.exists():
            inbox_file.rename(DONE / f"{msg_id}.json")
        if outbox_file.exists():
            outbox_file.rename(DONE / f"{msg_id}.reply.json")
        (DONE / f"{msg_id}.{marker}").write_text("", encoding="utf-8")

    # -- proactive messages ----------------------------------------------

    async def proactive_loop(self) -> None:
        while True:
            try:
                for path in sorted(p for p in PROACTIVE.glob("*.json") if not p.name.startswith(".")):
                    await self._handle_proactive_file(path)
            except Exception:
                logger.exception("proactive scan failed")
            await asyncio.sleep(OUTBOX_POLL_SECONDS)

    async def _handle_proactive_file(self, path: Path) -> None:
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return  # still being written; retry on the next poll
        scene = str(payload.get("scene") or "")
        target = str(payload.get("target") or "")
        content = str(payload.get("content") or "").strip()
        markdown = bool(payload.get("markdown"))
        media = self._validated_media(payload)
        if scene not in ("c2c", "group") or not target or media is None or (
            not content and not media
        ):
            logger.warning("proactive file %s is invalid; archiving as FAILED", path.name)
            self._archive_proactive(path, "FAILED")
            return
        try:
            await self._deliver(
                scene,
                target,
                text=content,
                markdown=markdown,
                media=media,
                reply_to=None,
            )
        except Exception as exc:
            # Log the platform error verbatim (HTTP status / biz code +
            # message) so quota problems are visible exactly as reported.
            logger.error("proactive send failed for %s: %s", path.name, exc)
            self._archive_proactive(path, "FAILED")
            return
        logger.info("proactive message sent from %s to %s/%s", path.name, scene, target)
        self._archive_proactive(path, "SENT")

    def _archive_proactive(self, path: Path, marker: str) -> None:
        DONE.mkdir(parents=True, exist_ok=True)
        archived = DONE / f"{path.stem}.proactive.json"
        if path.exists():
            path.rename(archived)
        (DONE / f"{path.stem}.{marker}").write_text("", encoding="utf-8")


async def main() -> int:
    for directory in (INBOX, OUTBOX, PROACTIVE, EVENTS, DONE, LOGS, STATE):
        directory.mkdir(parents=True, exist_ok=True)
    setup_logging()

    creds = load_credentials()
    if creds is None:
        logger.error(
            "credentials missing: QQBOT_APP_ID / QQBOT_APP_SECRET are not set. "
            "Put them in %s (KEY=VALUE lines) or export them in the environment. "
            "Exiting.",
            CREDENTIALS_FILE,
        )
        return 2
    app_id, secret = creds
    masked = "****" + app_id[-4:] if len(app_id) >= 4 else "****"
    logger.info("qq-bridge starting (app_id %s)", masked)

    http_client = httpx.AsyncClient(timeout=30.0)
    api = QQApiClient(app_id=app_id, client_secret=secret, log_tag="QQBridge")
    api.setup(http_client)
    bridge = Bridge(app_id, api, http_client=http_client)

    # Gateway liveness: heartbeat ACKs (and connect/ready events) refresh
    # this timestamp. See liveness_loop below.
    liveness = {"t": time.monotonic()}

    def _touch() -> None:
        liveness["t"] = time.monotonic()

    def _on_connected() -> None:
        _touch()
        logger.info("gateway connected")

    def _on_ready(ready: Any) -> None:
        _touch()
        bridge.on_ready(ready)

    try:
        await api.ensure_token()
    except Exception:
        logger.exception("failed to obtain access token; check credentials/network")
        return 3
    try:
        gateway_url = await api.get_gateway_url()
    except Exception:
        logger.exception("failed to obtain gateway URL")
        return 3

    callbacks = WSCallbacks(
        on_message_event=bridge.on_message_event,
        on_interaction_event=bridge.on_interaction_event,
        on_connected=_on_connected,
        on_disconnected=lambda: logger.warning("gateway disconnected"),
        on_fatal_error=lambda code, msg: logger.error(
            "gateway fatal error [%s]: %s", code, msg
        ),
        get_token=api.ensure_token_sync,
        get_gateway_url=api.get_gateway_url_sync,
        get_session=bridge.get_session,
        set_session=bridge.set_session,
        set_heartbeat_interval=lambda interval: logger.debug(
            "heartbeat interval %.0fs", interval
        ),
        clear_token=api.clear_token,
        fail_pending=lambda reason: logger.warning(
            "pending requests failed: %s", reason
        ),
        on_ready=_on_ready,
        on_heartbeat_ack=_touch,
    )
    ws = BridgeWebSocket(callbacks=callbacks, log_tag="QQBridge")
    ws.lifecycle_handler = bridge.on_lifecycle_event

    loop = asyncio.get_running_loop()
    stop_event = asyncio.Event()
    for sig in (signal.SIGTERM, signal.SIGINT):
        try:
            loop.add_signal_handler(sig, stop_event.set)
        except NotImplementedError:
            pass

    ws.start(gateway_url, loop)
    async def liveness_loop() -> None:
        # The SDK's reconnect can wedge after a dropped gateway connection
        # (observed 2026-11-08: overnight stalls of ~24 and ~74 minutes
        # after a single "Reconnecting" log line, bridge effectively
        # offline). Heartbeat ACKs arrive every heartbeat interval while
        # the gateway is healthy; if none (and no connect/ready) for
        # 5 minutes, exit hard and let the watchdog relaunch fresh.
        while True:
            await asyncio.sleep(60)
            silent_for = time.monotonic() - liveness["t"]
            if silent_for > 300:
                logger.error(
                    "gateway silent for %.0fs; exiting for watchdog restart",
                    silent_for,
                )
                os._exit(4)

    watchers = [
        asyncio.create_task(bridge.outbox_loop()),
        asyncio.create_task(bridge.proactive_loop()),
        asyncio.create_task(liveness_loop()),
    ]
    logger.info("qq-bridge running; watching %s and %s", OUTBOX, PROACTIVE)
    try:
        await stop_event.wait()
    finally:
        for watcher in watchers:
            watcher.cancel()
        ws.stop()
        logger.info("qq-bridge stopped")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
