# QQ 官方机器人文件桥

- 用这份技能把 QQ 官方机器人接到 Muse 本人身上。参考安装已于 2026-11-07 在这台 VM 上建成并真机验收，桥在 `~/workspace/qq-bridge/`，完整实现文件打包在本技能的 `references/implementation/` 里，照着复制就能重建。

## 架构与原则

- 走文件桥。守护进程只负责收发消息，回复内容由被唤醒的 agent 回合按人格与记忆写出，中间不接任何第三方模型。

- 只走官方路线。用 QQ 开放平台 Bot API v2 加腾讯官方 `qqbot-agent-sdk`，不用 NapCat、Lagrange 等非官方协议端。

- 按被动回复设计整条链路。平台只允许在原消息发出后 5 分钟内引用回复，每一环的延迟都为这个窗口让路。

## 平台侧准备

- 在 QQ 开放平台创建机器人，拿到 AppID 与 AppSecret。

- 先确认主体限制。个人主体可以用自有群（上限 500 人）和开发期体验用户私聊，公开投放需要企业主体。

- 开通事件订阅 `C2C_MESSAGE_CREATE` 与 `GROUP_AT_MESSAGE_CREATE`，intent 为 `GROUP_MESSAGES`，SDK 默认已带。

- 要接收不 @ 机器人的群消息时，另行给机器人开群全量消息权限，否则 `GROUP_MESSAGE_CREATE` 不会到达。

- 记住主动消息配额。私聊主动消息每人每天 2 条，只留给要紧事，不当推送通道用。

## 装 SDK 与目录

- 在桥目录建 Python venv，装 `qqbot-agent-sdk` 1.2.2。升级版本前先跑离线测试确认缺口补丁还成立。

- 建目录 `inbox`、`outbox`、`proactive`、`events`、`done`、`logs`、`state`。

- 从 `references/implementation/` 复制参考实现作为起点，内含 `daemon.py`、离线测试、扫码绑定脚本、两个 hook 脚本和 systemd 单元，运维细节看同目录的 `README.md`。

## 绑定凭据

- 首选扫码绑定。在 `qr-connect/` 里装 `@tencent-connect/qqbot-connector` 1.2.0 与 `qrcode`，跑 `connect.mjs` 生成 `qr.png` 给用户扫，成功回调把凭据写进 `credentials.env` 并设权限 0600。

- 备选手动绑定。把 `credentials.env.example` 复制为 `credentials.env`，填 AppID 与 AppSecret，同样设 0600。

- 永远不把 AppSecret 写进聊天或日志。汇报绑定结果只报 AppID 的掩码形式。

## 守护进程的职责与 SDK 缺口

- 让 `daemon.py` 用 SDK 的网关与 OpenAPI 收消息并原子写入 `inbox` 记录，每 3 秒轮询 `outbox` 发被动回复，处理完把文件归档到 `done/` 并打 SENT、EXPIRED、INVALID 或 ORPHAN 标记。

- 启动时先清洗 `NO_PROXY`，剔除方括号形式的 IPv6 条目，否则 httpx 会以 InvalidURL 报错让守护进程直接崩溃。

- 补 `GROUP_MESSAGE_CREATE`。SDK 1.2.2 不路由这个事件，向 `EventParser._EVENT_HANDLERS` 注册解析函数并子类化 `QQWebSocket` 覆写分发方法，生命周期事件走同一条通道记入 `events/events.jsonl`。

- 补频道私信发送。SDK 没有现成方法，用它的通用 `request()` 直调官方 `POST /dms/{guild_id}/messages`。

- 附件只存元数据与 `att.resolved_url` 原文。纯附件消息也要入箱并标 `attachment_only`，不要丢弃。

- 语音走 SDK 的 STTPipeline。未配置 STT 引擎时回退平台自带的 `asr_refer_text`，转写不到就如实标 `asr_text` 为 null 并在 `asr_note` 写原因，不伪造转写。

- 按钮交互用 `acknowledge_interaction` 确认。C2C 消息入箱时发 `send_typing` 给用户即时反馈。

- 主动消息读 `proactive/` 目录发
...[truncated 3072 chars]